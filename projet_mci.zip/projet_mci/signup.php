<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Creer Compte</title>
  </head>
  <body>
    <section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content">
      <div class="logo">
        <h1>Ministere Du Commerce Et de L'Industrie</h1>
      </div>
      <div class="login-box">
        <form method = "post" class="login-form" action="controller/inscription.php">
          <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>Creer Un Compte</h3>
          <div class="form-group">
            <label class="control-label">Nom</label>
            <input class="form-control" type="text" placeholder="NOM" autofocus name="nom">
          </div>
          <div class="form-group">
            <label class="control-label">Prenom</label>
            <input class="form-control" type="text" placeholder="Prenom" name="prenom">
          </div>
          <label class="control-label">Sexe</label>
                    <div class="form-check">
                      <label class="form-check-label">
                        <input class="form-check-input" id="optionsRadios1" type="radio" name="sexe" value="m" checked="">Male
                      </label>
                    </br>
                      <label class="form-check-label">
                      <input class="form-check-input" id="optionsRadios2" type="radio" name="sexe" value="f" checked="">Femele
                      </label>
                      </br>
                      <label class="form-check-label">
                      <input class="form-check-input" id="optionsRadios3" type="radio" name="sexe" value="a" >Autre
                      </label>
                    </div>
                  </br>
          <div class="form-group">
            <label class="control-label">Adresse</label>
            <input class="form-control" type="text" placeholder="Adresse" autofocus name="adresse">
          </div>
          <div class="form-group">
            <label class="control-label">Telephone</label>
            <input class="form-control" type="text" placeholder="Telephone" name="telephone">
          </div>
          <div class="form-group">
            <label class="control-label">Email</label>
            <input class="form-control" type="email" placeholder="Email" autofocus name="email">
          </div>
          <div class="form-group">
            <label class="control-label">Mot de Passe</label>
            <input class="form-control" type="password" placeholder="Mot de Passe" name="mot_de_passe">
            <div class="form-group">
            <label class="control-label">Confirmation Mot de Passe</label>
            <input class="form-control" type="password" placeholder="Mot de Passe">
          </div>
          <div class="form-group">
            <div class="utility">
              
            </div>
          </div>
          <div class="form-group btn-container">
            <input type="submit" value="Enregistrement" class="btn btn-primary btn-block">
          </div>
        </form>
      </div>
    </section>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <script type="text/javascript">
      // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
      	$('.login-box').toggleClass('flipped');
      	return false;
      });
    </script>
  </body>
</html>