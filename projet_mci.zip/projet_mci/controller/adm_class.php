<?php 
 /**
  * summary
  */
 class Connexion_adm
 {
 	
     protected $email;
     protected $mot_de_passe;
     
     public function getEmail()
     {
     	return $this->email;

     }

     public function getMot_de_passe()
     {
     	return $this->mot_de_passe;
     }
     public function __construct($email, $password)
     {
         $this->email = $email;
         $this->mot_de_passe= $password;
     }
 }

 
 /**
  * summary
  */
 class Inscription
 {
     protected $nom;
     protected $prenom;
     protected $adresse;
     protected $sexe;
     protected $telephone;
     protected $email;
     protected $mot_de_passe;

     public function getNom()
     {
     	return $this->nom;
     }
     public function getPrenom()
     {
     	return $this->prenom;
     }
     public function getAdresse()
     {
     	return $this->adresse;
     }
     public function getTelephone()
     {
     	return $this->telephone;
     }
     public function getEmail()
     {
     	return $this->email;
     }
     public function getMot_de_passe()
     {
     	return $this->mot_de_passe;
     }
     public function getSexe()
     {
     	return $this->sexe;
     }
     public function __construct($nom, $prenom, $sexe,$adresse, $telephone, $email, $pass )
     {
         $this->nom = $nom; 
         $this->prenom = $prenom;
         $this->sexe = $sexe;
         $this->adresse= $adresse;
         $this->telephone = $telephone;
         $this->email = $email;
         $this->mot_de_passe= $pass;
         
     }
 }
 ?>