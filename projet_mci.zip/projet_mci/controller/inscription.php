<?php 

if (isset($_POST['nom']) AND isset($_POST['prenom']) AND isset($_POST['sexe']) AND isset($_POST['adresse']) AND isset($_POST['telephone']) AND isset($_POST['email']) AND isset($_POST['mot_de_passe'])) {
	
   include_once("adm_class.php");
   $inscription = new Inscription($_POST['nom'],$_POST['prenom'],$_POST['sexe'], $_POST['adresse'],$_POST['telephone'],$_POST['email'], $_POST['mot_de_passe']);
   $bd = new PDO('mysql:host=localhost; dbname=mci_db', 'root', '');
   $con = $bd->prepare("INSERT INTO `utilisateur`(`nom`, `prenom`, `sexe`, `adresse`, `telephone`, `email`, `mot_de_passe`, `statut`) VALUES (?,?,?,?,?,?,?,?)");
   $con->execute(array(
   	$inscription->getNom(),
    $inscription->getPrenom(),
    $inscription->getSexe(),
    $inscription->getAdresse(),
    $inscription->getTelephone(),
    $inscription->getEmail(),
    $inscription->getMot_de_passe(),
    "client"
   ));
   $con2 = $bd->prepare("SELECT `id_user` FROM `utilisateur` WHERE `email`=? ");
   $con2->execute(array(
   	$inscription->getEmail()
   ));
   $id = $con2->fetch();

   ini_set( 'display_errors', 1 );
 
    error_reporting( E_ALL );
 
    $from = "eloirochard1997@gmail.com";
 
    $to = $inscription->getEmail();
 
    $subject = "Confirmation";
 
    $message = "Ceci est n email de confirmation, cliquer sur le lien <a href='bonjour.php?nom=Eloi".$id["id_user"]."'>pour confirmer votre inscription</a>";
 
    $headers = "From:" . $from;
 
    mail($to,$subject,$message, $headers);
 
    echo 'Un email a ete envoyer. Confirmer votre email';
}
?>