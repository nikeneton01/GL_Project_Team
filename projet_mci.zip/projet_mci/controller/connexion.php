<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php

if(isset($_POST['email']) AND isset($_POST['password']))
{
	include_once("adm_class.php");
	$connexion = new connexion_adm($_POST['email'], $_POST['password']);
	$bd = new PDO('mysql:host=localhost; dbname=mci_db', 'root', '');
    $con = $bd->prepare("SELECT `nom`, `prenom`,`email`, `mot_de_passe`,`statut` FROM `utilisateur` WHERE `email`= ?");


$con->execute(array(
	$connexion->getEmail()
 )
);
   $donnee = $con->fetch();
    if($donnee['mot_de_passe'] == $connexion->getMot_de_passe() AND $connexion->getMot_de_passe()!="")
    {
    	?>
    	<script type="text/javascript">
    		console.log("Mot de passe Correct");
    	</script>
    	<?php
    	if($donnee['statut']== "admin")
    	{

    		$_SESSION['nom']= $donnee['nom'] ;
    		$_SESSION['prenom']= $donnee['prenom'];
        
    	header("location:../src_adm/index.php?nom=".$donnee['nom']."&prenom=".$donnee['prenom']);
    	}
    	else
    	{
    		header("location:../src_client/index.php");
    	}
    	
    }
    else
    {

    	$_SESSION['incorrect']= "incorrect" ;
    	echo ' '.$_SESSION['incorrect'];
    	header("location:../index.php");
    }
       


	
}

?>
</body>
</html>
<?php
