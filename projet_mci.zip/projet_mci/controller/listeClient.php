<?php 

$bd = new PDO('mysql:host=localhost; dbname=mci_db', 'root', '');
   $con = $bd->prepare("SELECT `id_user`, `nom`, `prenom`, `sexe`, `adresse`, `telephone`, `email` FROM `utilisateur` WHERE `statut`=? ");
   $con->execute(array("client"));
   while($donnee = $con->fetch())
   {
    ?>

    <tr>
                    <td><?php echo $donnee['id_user'] ?></td>
                    <td><?php echo $donnee['nom'] ?></td>
                    <td><?php echo $donnee['prenom'] ?></td>
                    <td><?php echo $donnee['sexe'] ?></td>
                    <td><?php echo $donnee['adresse'] ?></td>
                    <td><?php echo $donnee['telephone'] ?></td>
                    <td><?php echo $donnee['email'] ?></td>
    </tr>
 <?php
   }

 ?>