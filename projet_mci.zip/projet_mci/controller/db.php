<?php 
try {

	$bd = new PDO('mysql:host=localhost; dbname=mci_db', 'root', '');
	
} catch (Exception $e) {
	
	
}


 ?>